// Sample rural facility network (illustrative coordinates around a Telangana
// district cluster). Replace with a real PHC/CHC dataset for production use —
// see README for the data schema.
export const initialFacilities = [
  {
    id: "phc-1",
    name: "Shamshabad PHC",
    lat: 17.2403,
    lon: 78.4294,
    tier: "PHC",
    capacity: { icuBeds: 0, generalBeds: 6, opdSlots: 20 },
    used: { icuBeds: 0, generalBeds: 0, opdSlots: 0 },
  },
  {
    id: "chc-1",
    name: "Chevella CHC",
    lat: 17.3167,
    lon: 78.1333,
    tier: "CHC",
    capacity: { icuBeds: 2, generalBeds: 14, opdSlots: 30 },
    used: { icuBeds: 0, generalBeds: 0, opdSlots: 0 },
  },
  {
    id: "dh-1",
    name: "Vikarabad District Hospital",
    lat: 17.3378,
    lon: 77.9048,
    tier: "District Hospital",
    capacity: { icuBeds: 8, generalBeds: 40, opdSlots: 60 },
    used: { icuBeds: 0, generalBeds: 0, opdSlots: 0 },
  },
  {
    id: "phc-2",
    name: "Moinabad PHC",
    lat: 17.2833,
    lon: 78.2333,
    tier: "PHC",
    capacity: { icuBeds: 0, generalBeds: 4, opdSlots: 15 },
    used: { icuBeds: 0, generalBeds: 0, opdSlots: 0 },
  },
  {
    id: "chc-2",
    name: "Tandur CHC",
    lat: 17.2544,
    lon: 77.5834,
    tier: "CHC",
    capacity: { icuBeds: 3, generalBeds: 16, opdSlots: 25 },
    used: { icuBeds: 0, generalBeds: 0, opdSlots: 0 },
  },
];

// Rough village/incident locations for demo intake (so distance calc has meaning)
export const sampleLocations = [
  { label: "Shamshabad village", lat: 17.245, lon: 78.42 },
  { label: "Chevella town", lat: 17.31, lon: 78.14 },
  { label: "Vikarabad town", lat: 17.335, lon: 77.9 },
  { label: "Moinabad", lat: 17.28, lon: 78.24 },
  { label: "Tandur town", lat: 17.25, lon: 77.58 },
  { label: "Kothur road (highway accident spot)", lat: 17.27, lon: 78.31 },
];
