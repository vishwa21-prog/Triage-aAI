import { useEffect, useState } from 'react';

export default function TopBar({ stats }) {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const time = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const date = now.toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short' });

  return (
    <header className="topbar">
      <div className="topbar-brand">
        <span className="topbar-mark" aria-hidden="true" />
        <div>
          <div className="topbar-title">TriageAI</div>
          <div className="topbar-subtitle">Rural Emergency Triage &amp; Resource Allocation</div>
        </div>
      </div>

      <div className="topbar-stats">
        <StatPill label="In queue" value={stats.queued} />
        <StatPill label="Immediate" value={stats.red} tone="red" />
        <StatPill label="Urgent" value={stats.yellow} tone="amber" />
        <StatPill label="Unassigned" value={stats.unassigned} tone={stats.unassigned > 0 ? 'red' : undefined} />
      </div>

      <div className="topbar-clock mono">
        <div>{time}</div>
        <div className="topbar-date">{date}</div>
      </div>
    </header>
  );
}

function StatPill({ label, value, tone }) {
  return (
    <div className={`stat-pill ${tone ? `tone-${tone}` : ''}`}>
      <span className="stat-pill-value mono">{value}</span>
      <span className="stat-pill-label">{label}</span>
    </div>
  );
}
