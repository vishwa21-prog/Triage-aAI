const RESOURCE_LABELS = {
  icuBeds: 'ICU beds',
  generalBeds: 'General beds',
  opdSlots: 'OPD slots',
};

export default function FacilityBoard({ facilities }) {
  return (
    <section className="panel facility-panel">
      <div className="panel-header">
        <h2>Facility network</h2>
        <span className="panel-eyebrow">03 — live capacity</span>
      </div>

      <div className="facility-list">
        {facilities.map((f) => (
          <div key={f.id} className="facility-card">
            <div className="facility-card-head">
              <span className="facility-name">{f.name}</span>
              <span className="facility-tier">{f.tier}</span>
            </div>
            {Object.keys(f.capacity).map((key) => {
              const used = f.used[key] || 0;
              const cap = f.capacity[key];
              const pct = cap === 0 ? 0 : Math.min(100, Math.round((used / cap) * 100));
              const full = cap === 0;
              return (
                <div key={key} className="resource-row">
                  <div className="resource-row-label">
                    <span>{RESOURCE_LABELS[key]}</span>
                    <span className="mono">{full ? '—' : `${used}/${cap}`}</span>
                  </div>
                  <div className="resource-bar-track">
                    <div
                      className={`resource-bar-fill ${pct >= 90 ? 'crit' : pct >= 60 ? 'warn' : ''}`}
                      style={{ width: full ? '0%' : `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </section>
  );
}
