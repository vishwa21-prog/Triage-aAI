export default function Analytics({ patients, assignments, unassigned }) {
  const avgScore = patients.length
    ? Math.round(patients.reduce((s, p) => s + p.acuity.score, 0) / patients.length)
    : 0;

  const avgEta = assignments.length
    ? Math.round(assignments.reduce((s, a) => s + a.etaMin, 0) / assignments.length)
    : 0;

  const ambulanceCount = assignments.filter((a) => a.dispatchAmbulance).length;

  return (
    <section className="panel analytics-panel">
      <div className="panel-header">
        <h2>Ops snapshot</h2>
        <span className="panel-eyebrow">04 — computed</span>
      </div>
      <div className="analytics-grid">
        <Metric label="Avg acuity score" value={avgScore} />
        <Metric label="Avg ETA to care" value={`${avgEta}m`} />
        <Metric label="Ambulances dispatched" value={ambulanceCount} />
        <Metric label="Escalation needed" value={unassigned.length} warn={unassigned.length > 0} />
      </div>
    </section>
  );
}

function Metric({ label, value, warn }) {
  return (
    <div className={`metric ${warn ? 'metric-warn' : ''}`}>
      <div className="metric-value mono">{value}</div>
      <div className="metric-label">{label}</div>
    </div>
  );
}
