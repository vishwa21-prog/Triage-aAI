import PatientCard from './PatientCard';

export default function PatientQueue({ patients, assignmentsByPatient, onResolve }) {
  return (
    <section className="panel queue-panel">
      <div className="panel-header">
        <h2>Live patient queue</h2>
        <span className="panel-eyebrow">02 — ranked by acuity</span>
      </div>

      {patients.length === 0 ? (
        <div className="empty-state">
          No patients in queue. Admit a patient on the left to see triage scoring and allocation run live.
        </div>
      ) : (
        <ul className="patient-list">
          {patients.map((p) => (
            <PatientCard
              key={p.id}
              patient={p}
              assignment={assignmentsByPatient[p.id]}
              onResolve={onResolve}
            />
          ))}
        </ul>
      )}
    </section>
  );
}
