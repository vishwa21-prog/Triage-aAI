function timeAgo(ts) {
  const mins = Math.max(0, Math.round((Date.now() - ts) / 60000));
  if (mins < 1) return 'just now';
  if (mins === 1) return '1 min ago';
  return `${mins} min ago`;
}

export default function PatientCard({ patient, assignment, onResolve }) {
  const { category, score } = patient.acuity;
  const tone = category.key.toLowerCase();

  return (
    <li className={`patient-card tone-${tone} ${category.key === 'RED' ? 'pulse' : ''}`}>
      <div className="patient-card-strip" style={{ background: category.color }} aria-hidden="true" />
      <div className="patient-card-body">
        <div className="patient-card-top">
          <div>
            <div className="patient-card-name">{patient.name}</div>
            <div className="patient-card-meta">
              {patient.age != null ? `${patient.age}y · ` : ''}{patient.locationLabel} · {timeAgo(patient.intakeTime)}
            </div>
          </div>
          <div className="patient-card-score">
            <span className="mono score-value">{score}</span>
            <span className={`category-badge tone-${tone}`}>{category.label}</span>
          </div>
        </div>

        {patient.complaint && <p className="patient-card-complaint">&ldquo;{patient.complaint}&rdquo;</p>}

        {patient.acuity.breakdown.length > 0 && (
          <div className="patient-card-breakdown">
            {patient.acuity.breakdown.map((b, i) => (
              <span key={i} className="breakdown-chip">{b.label} <span className="mono">+{b.points}</span></span>
            ))}
          </div>
        )}

        <div className="patient-card-footer">
          {assignment ? (
            <div className="assignment-line">
              <span className="assignment-arrow">→</span>
              <strong>{assignment.facilityName}</strong>
              <span className="assignment-detail mono">{assignment.distanceKm} km · ETA {assignment.etaMin} min</span>
              {assignment.dispatchAmbulance && <span className="ambulance-tag">🚑 Ambulance dispatched</span>}
            </div>
          ) : (
            <div className="assignment-line unassigned">No capacity available — escalate</div>
          )}
          <button className="btn-ghost" onClick={() => onResolve(patient.id)}>Mark resolved</button>
        </div>
      </div>
    </li>
  );
}
