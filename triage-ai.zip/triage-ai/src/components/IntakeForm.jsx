import { useMemo, useState } from 'react';
import { parseSymptoms } from '../lib/symptomParser';
import { sampleLocations } from '../data/facilities';

const AVPU_OPTIONS = [
  { value: 'A', label: 'A — Alert' },
  { value: 'V', label: 'V — Responds to voice' },
  { value: 'P', label: 'P — Responds to pain only' },
  { value: 'U', label: 'U — Unresponsive' },
];

const initialState = {
  name: '',
  age: '',
  locationLabel: sampleLocations[0].label,
  respRate: '',
  pulse: '',
  systolicBP: '',
  avpu: 'A',
  capRefill: '',
  canWalk: false,
  complaint: '',
};

export default function IntakeForm({ onAdmit }) {
  const [form, setForm] = useState(initialState);

  const symptomPreview = useMemo(() => parseSymptoms(form.complaint), [form.complaint]);

  const update = (key) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [key]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    const location = sampleLocations.find((l) => l.label === form.locationLabel);

    onAdmit({
      name: form.name.trim(),
      age: form.age === '' ? null : Number(form.age),
      location: location ? { lat: location.lat, lon: location.lon } : null,
      locationLabel: form.locationLabel,
      vitals: {
        age: form.age === '' ? null : Number(form.age),
        respRate: form.respRate === '' ? null : Number(form.respRate),
        pulse: form.pulse === '' ? null : Number(form.pulse),
        systolicBP: form.systolicBP === '' ? null : Number(form.systolicBP),
        avpu: form.avpu,
        capRefill: form.capRefill === '' ? null : Number(form.capRefill),
        canWalk: form.canWalk,
      },
      complaint: form.complaint,
    });

    setForm(initialState);
  };

  return (
    <form className="panel intake-form" onSubmit={handleSubmit}>
      <div className="panel-header">
        <h2>New patient intake</h2>
        <span className="panel-eyebrow">01 — capture</span>
      </div>

      <div className="field-row">
        <label className="field">
          <span>Patient name</span>
          <input required value={form.name} onChange={update('name')} placeholder="e.g. Lakshmi Devi" />
        </label>
        <label className="field field-narrow">
          <span>Age</span>
          <input type="number" min="0" max="120" value={form.age} onChange={update('age')} placeholder="—" />
        </label>
      </div>

      <label className="field">
        <span>Location</span>
        <select value={form.locationLabel} onChange={update('locationLabel')}>
          {sampleLocations.map((l) => (
            <option key={l.label} value={l.label}>{l.label}</option>
          ))}
        </select>
      </label>

      <div className="field-group-label">Vitals</div>
      <div className="field-row four">
        <label className="field">
          <span>Resp. rate /min</span>
          <input type="number" min="0" max="60" value={form.respRate} onChange={update('respRate')} placeholder="16" />
        </label>
        <label className="field">
          <span>Pulse /min</span>
          <input type="number" min="0" max="250" value={form.pulse} onChange={update('pulse')} placeholder="80" />
        </label>
        <label className="field">
          <span>Systolic BP</span>
          <input type="number" min="0" max="300" value={form.systolicBP} onChange={update('systolicBP')} placeholder="120" />
        </label>
        <label className="field">
          <span>Cap. refill (s)</span>
          <input type="number" min="0" max="10" step="0.5" value={form.capRefill} onChange={update('capRefill')} placeholder="2" />
        </label>
      </div>

      <div className="field-row">
        <label className="field">
          <span>Consciousness (AVPU)</span>
          <select value={form.avpu} onChange={update('avpu')}>
            {AVPU_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </label>
        <label className="field field-checkbox">
          <input type="checkbox" checked={form.canWalk} onChange={update('canWalk')} />
          <span>Ambulatory (can walk)</span>
        </label>
      </div>

      <label className="field">
        <span>Presenting complaint (free text, any language mix)</span>
        <textarea
          rows={3}
          value={form.complaint}
          onChange={update('complaint')}
          placeholder="e.g. Severe chest pain since 20 minutes, sweating, can't breathe properly"
        />
      </label>

      {form.complaint.trim() && (
        <div className="flag-preview" aria-live="polite">
          <span className="flag-preview-label">Detected flags</span>
          {symptomPreview.flags.length === 0 ? (
            <span className="flag-chip flag-chip-none">No red flags detected</span>
          ) : (
            <div className="flag-chip-row">
              {symptomPreview.flags.map((f) => (
                <span key={f.id} className={`flag-chip flag-chip-${f.system}`}>{f.label}</span>
              ))}
            </div>
          )}
        </div>
      )}

      <button type="submit" className="btn-primary">Score &amp; admit to queue</button>
    </form>
  );
}
