import { useMemo, useState } from 'react';
import TopBar from './components/TopBar';
import IntakeForm from './components/IntakeForm';
import PatientQueue from './components/PatientQueue';
import FacilityBoard from './components/FacilityBoard';
import Analytics from './components/Analytics';
import { parseSymptoms } from './lib/symptomParser';
import { computeAcuity, rankPatients } from './lib/triageEngine';
import { allocateResources } from './lib/resourceAllocator';
import { initialFacilities } from './data/facilities';
import './App.css';

let idCounter = 1;

export default function App() {
  const [patients, setPatients] = useState([]);
  const [facilities] = useState(initialFacilities);

  const handleAdmit = (intake) => {
    const symptomResult = parseSymptoms(intake.complaint);
    const acuity = computeAcuity(intake.vitals, symptomResult);

    const patient = {
      id: `p-${idCounter++}`,
      name: intake.name,
      age: intake.age,
      location: intake.location,
      locationLabel: intake.locationLabel,
      complaint: intake.complaint,
      symptomResult,
      acuity,
      intakeTime: Date.now(),
    };

    setPatients((prev) => [...prev, patient]);
  };

  const handleResolve = (id) => {
    setPatients((prev) => prev.filter((p) => p.id !== id));
  };

  const ranked = useMemo(() => rankPatients(patients), [patients]);

  const { assignments, unassigned, facilitiesAfter } = useMemo(
    () => allocateResources(ranked, facilities),
    [ranked, facilities]
  );

  const assignmentsByPatient = useMemo(() => {
    const map = {};
    for (const a of assignments) map[a.patientId] = a;
    return map;
  }, [assignments]);

  const stats = useMemo(
    () => ({
      queued: patients.length,
      red: patients.filter((p) => p.acuity.category.key === 'RED').length,
      yellow: patients.filter((p) => p.acuity.category.key === 'YELLOW').length,
      unassigned: unassigned.length,
    }),
    [patients, unassigned]
  );

  return (
    <div className="app-shell">
      <TopBar stats={stats} />
      <main className="app-grid">
        <div className="col col-intake">
          <IntakeForm onAdmit={handleAdmit} />
        </div>
        <div className="col col-queue">
          <PatientQueue
            patients={ranked}
            assignmentsByPatient={assignmentsByPatient}
            onResolve={handleResolve}
          />
        </div>
        <div className="col col-facility">
          <Analytics patients={patients} assignments={assignments} unassigned={unassigned} />
          <FacilityBoard facilities={facilitiesAfter} />
        </div>
      </main>
      <footer className="app-footer">
        Idea2Impact 2026 · Theme 3 — Crisis Management, HealthTech &amp; Emergency Response · Triage scoring runs entirely client-side, no patient data leaves the browser.
      </footer>
    </div>
  );
}
